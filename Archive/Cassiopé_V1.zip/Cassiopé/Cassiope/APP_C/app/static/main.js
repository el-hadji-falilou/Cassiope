// Placez ici votre code AJAX si nécessaire
console.log("static/main.js loaded");
